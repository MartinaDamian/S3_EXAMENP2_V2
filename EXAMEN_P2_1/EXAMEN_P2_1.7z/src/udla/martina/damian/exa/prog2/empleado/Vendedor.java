package udla.martina.damian.exa.prog2.empleado;

import udla.martina.damian.exa.prog2.Empleado;

public class Vendedor extends Empleado {
    private double comision;

    public Vendedor(String id, String nombre, double salario, double comision) {
        super(id, nombre, salario);
        this.comision = comision;
    }

    public double getComision() {
        return comision;
    }


}
