package udla.martina.damian.exa.prog2;

import java.util.List;

public class Venta {
    private String id;
    private String fecha;
    private Empleado empleado;
    private List<Producto> productosVendidos;
    private double total;
    public Venta(){
    }
    public Venta(String id, String fecha, Empleado empleado, List<Producto> productosVendidos, double total) {
        this.id = id;
        this.fecha = fecha;
        this.empleado = empleado;
        this.productosVendidos = productosVendidos;
        this.total = total;
    }
    public void agregarProducto(Producto producto, int cantidad){
        if(producto.getCantiddad()>=cantidad){
            producto.reducirCantidad(cantidad);
            productosVendidos.add(producto);
            total+= producto.getPrecios();
            System.out.printf("Producto " + producto.getCantiddad() + " " +producto.getNombre() + " agregado a la compra ");
        }else{
            System.out.printf("No existe suficiente cantidad para la venta");
        }
    }
    public double getTotal() {
        return total;
    }

}
