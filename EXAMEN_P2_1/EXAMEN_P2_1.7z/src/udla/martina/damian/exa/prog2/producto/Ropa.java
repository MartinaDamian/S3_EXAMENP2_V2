package udla.martina.damian.exa.prog2.producto;

import udla.martina.damian.exa.prog2.Producto;

public class Ropa extends Producto {
    private String talla;
    private String sexo;
    private String categoria;

    public Ropa(String codigo, String nombre, double precios, Integer cantiddad, String talla, String sexo, String categoria) {
        super(codigo, nombre, precios, cantiddad);
        this.talla = talla;
        this.sexo = sexo;
        this.categoria = categoria;
    }

    public String getTalla() {
        return talla;
    }

    public String getSexo() {
        return sexo;
    }

    public String getCategoria() {
        return categoria;
    }

    @Override
    public void detalle(){
        System.out.printf("Tipo: Calzado\n Talla: " + getTalla()+ "\n Categoria:" + getCategoria() + "\nSexo: "+ getSexo()+"\n Nombre:" + getNombre() + "\n Codigo: " + getCodigo() + "\n Precio: " + getPrecios() );
    };
}
