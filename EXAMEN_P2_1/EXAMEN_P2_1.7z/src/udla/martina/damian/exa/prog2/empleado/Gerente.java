package udla.martina.damian.exa.prog2.empleado;

import udla.martina.damian.exa.prog2.Empleado;

public class Gerente extends Empleado {
    private double bonoAnual;

    public Gerente(String id, String nombre, double salario, double bonoAnual) {
        super(id, nombre, salario);
        this.bonoAnual = bonoAnual;
    }

    public double getBonoAnual() {
        return bonoAnual;
    }

}
