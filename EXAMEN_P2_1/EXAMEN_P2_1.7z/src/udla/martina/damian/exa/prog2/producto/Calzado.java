package udla.martina.damian.exa.prog2.producto;

import udla.martina.damian.exa.prog2.Producto;

public class Calzado extends Producto {
    private Integer numero;
    private String sexo;
    private String color;

    public Calzado(String codigo, String nombre, double precios, Integer cantiddad, Integer numero, String sexo, String color) {
        super(codigo, nombre, precios, cantiddad);
        this.numero = numero;
        this.sexo = sexo;
        this.color = color;
    }

    public Integer getNumero() {
        return numero;
    }
    @Override
    public void detalle(){
        System.out.printf("Tipo: Calzado\n Talla: " + getNumero()+ "\n Color:" + color + "\n Nombre:" + getNombre() + "\n Codigo: " + getCodigo() + "\n Precio: " + getPrecios() );
    };
}
