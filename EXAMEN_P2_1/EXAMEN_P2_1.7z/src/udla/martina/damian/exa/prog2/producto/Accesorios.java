package udla.martina.damian.exa.prog2.producto;

import udla.martina.damian.exa.prog2.Producto;

public class Accesorios extends Producto {
    private String tipo;


    public Accesorios(String codigo, String nombre, double precios, Integer cantiddad, String tipo) {
        super(codigo, nombre, precios, cantiddad);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }
    @Override
    public void detalle(){
        System.out.printf("Tipo:"+ getTipo()+ "Nombre:" + getNombre() + "Codigo: " + getCodigo() + "Precio: " + getPrecios() );

    };
}
