package udla.martina.damian.exa.prog2;

abstract public class Producto {
    private String codigo;
    private String nombre;
    private double precios;
    private Integer cantidad;

    public Producto(String codigo, String nombre, double precios, Integer cantiddad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.precios = precios;
        this.cantidad = cantiddad;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecios() {
        return precios;
    }

    public Integer getCantiddad() {
        return cantidad;
    }
    public void reducirCantidad(Integer cantidadVendida){
        this.cantidad -= cantidadVendida;
    }
    public String toString(String codigo, String nombre, double precios, Integer cantiddad){
        String cv = "";

     return cv;
    }
    public void detalle(){};
}
